package es.upm.dit.prog.practica5;

public interface SelectorMision {

	public boolean seleccionar(Mision m);

}
