package es.upm.dit.prog.practica4;

public interface SelectorMision {

	public boolean seleccionar(Mision m);

}
